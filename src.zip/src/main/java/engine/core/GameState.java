package engine.core;

public enum GameState {
    MAIN_MENU,
    PLAYING,
    PAUSED,
    EXITING
}
